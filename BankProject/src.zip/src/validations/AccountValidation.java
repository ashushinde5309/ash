package validations;

public class AccountValidation {

}
