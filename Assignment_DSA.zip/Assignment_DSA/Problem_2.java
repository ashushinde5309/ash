package Assignment_DSA;

import java.util.Scanner;

class Node {
	int data;
	Node next;

	public Node(int data) {
		this.data = data;
		this.next = null;
	}
}

class SinglyLinkedList {
	Node n;

	public void insertSorted(int value) {
		Node newNode = new Node(value);
		if (n == null || n.data > value) {
			newNode.next = n;
			n = newNode;
		} else {
			Node current = n;
			while (current.next != null && current.next.data < value) {
				current = current.next;
			}
			newNode.next = current.next;
			current.next = newNode;
		}
	}

	public void display() {
		Node current = n;
		while (current != null) {
			System.out.print(current.data + " -> ");
			current = current.next;
		}
		System.out.println("null");
	}

	public SinglyLinkedList union(SinglyLinkedList otherList) {
		SinglyLinkedList unionList = new SinglyLinkedList();
		Node current1 = this.n;
		Node current2 = otherList.n;

		while (current1 != null || current2 != null) {
			if (current1 == null) {
				unionList.insertSorted(current2.data);
				current2 = current2.next;
			} else if (current2 == null) {
				unionList.insertSorted(current1.data);
				current1 = current1.next;
			} else if (current1.data < current2.data) {
				unionList.insertSorted(current1.data);
				current1 = current1.next;
			} else if (current1.data > current2.data) {
				unionList.insertSorted(current2.data);
				current2 = current2.next;
			} else {

				unionList.insertSorted(current1.data);
				current1 = current1.next;
				current2 = current2.next;
			}
		}

		return unionList;
	}
}

public class Problem_2 {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);

		SinglyLinkedList list1 = new SinglyLinkedList();
		System.out.println("Enter elements for the first sorted linked list (enter -1 to stop):");
		while (true) {
			int value = scanner.nextInt();
			if (value == -1)
				break;
			list1.insertSorted(value);
		}

		SinglyLinkedList list2 = new SinglyLinkedList();
		System.out.println("Enter elements for the second sorted linked list (enter -1 to stop):");
		while (true) {
			int value = scanner.nextInt();
			if (value == -1)
				break;
			list2.insertSorted(value);
		}

		System.out.println("First Linked List:");
		list1.display();

		System.out.println("Second Linked List:");
		list2.display();

		SinglyLinkedList unionList = list1.union(list2);
		System.out.println("Union of the two linked lists:");
		unionList.display();
	}

}
