package Assignment_DSA;

import java.util.Scanner;

class ReverseString {
	private char stack[];
	private int MaxSize;
	private int tos;

	public void create_Stack(int size) {
		tos = -1;
		stack = new char[size];
		MaxSize = size;

	}

	void push(char e) {
		tos++;
		stack[tos] = e;
	}

	boolean is_full() {
		if (tos == MaxSize - 1) {
			return true;

		} else {
			return false;
		}

	}

	char pop() {
		int temp = stack[tos];
		tos--;
		return (char) temp;

	}

	boolean is_empty() {
		if (tos == -1) {
			return true;

		} else {
			return false;
		}

	}

	int peek() {
		return stack[tos];
	}

	void print_Stack() {
		for (int i = tos; i >= 0; i--) {
			System.out.println(stack[i]);
		}

	}
}

public class Problem_1 {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		ReverseString obj = new ReverseString();
		System.out.println("Enter String: ");
		String word = sc.next();
		obj.create_Stack(word.length());
		for (int i = 0; i < word.length(); i++)

		{
			obj.push(word.charAt(i));
		}
		String r_word = "";
		while (obj.is_empty() != true) {
			r_word = r_word + obj.pop();
		}

		System.out.println("Reverse String is:" + r_word);
	}

}
