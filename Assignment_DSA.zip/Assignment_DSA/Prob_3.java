package Assignment_DSA;
import java.util.Scanner;

class Node {
    int data;
    Node next;

    public Node(int data) {
        this.data = data;
        this.next = null;
    }
}

class LinkedList {
    Node n;
    public void insert(int data) {
        Node newNode = new Node(data);
        if (n == null) {
            n = newNode;
        } else {
            Node current = n;
            while (current.next != null) {
                current = current.next;
            }
            current.next = newNode;
        }
    }

    public void display() {
        Node current = n;
        while (current != null) {
            System.out.print(current.data + " -> ");
            current = current.next;
        }
        System.out.println("null");
    }

}

public class Prob_3 {

	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
        System.out.print("Enter a number: ");
        String number = scanner.nextLine();
        LinkedList linkedList = new LinkedList();
        for (char digit : number.toCharArray()) {
            linkedList.insert(digit - '0');
        }
        System.out.println("Linked List from digits of the number:");
        linkedList.display();

		
	}

}
