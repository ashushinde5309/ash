package Tree_Examples;

import java.util.Scanner;

public class celebrity_Graph {
	int v; // Number of nodes
	int[][] g; // Adjacency matrix

	// Create a graph with 'nodes' number of nodes
	void createGraph(int nodes) {
		v = nodes;
		Scanner in = new Scanner(System.in);
		g = new int[v][v]; // Adjacency matrix

		for (int i = 0; i < v; i++) {
			for (int j = 0; j < v; j++) {
				System.out.println("Enter value for v" + i + " to v" + j + " (1 for knows, 0 for doesn't know):");
				g[i][j] = in.nextInt();
			}
		}
	}

	// Print the adjacency matrix
	void printG() {
		System.out.println("Adjacency Matrix:");
		for (int i = 0; i < v; i++) {
			for (int j = 0; j < v; j++) {
				System.out.print(g[i][j] + "\t");
			}
			System.out.println();
		}
	}

	// Function to find the celebrity
	void findCelebrity() {
		int candidate = 0;

		// Step 1: Find the candidate for the celebrity
		for (int i = 1; i < v; i++) {
			if (g[candidate][i] == 1) {
				candidate = i; // candidate is known by someone
			}
		}

		// Step 2: Verify the candidate
		boolean isCelebrity = true;

		for (int i = 0; i < v; i++) {
			// The candidate should not know anyone else
			if (i != candidate && g[candidate][i] == 1) {
				isCelebrity = false;
				break;
			}
			// Everyone else should know the candidate
			if (i != candidate && g[i][candidate] == 0) {
				isCelebrity = false;
				break;
			}
		}

		// Output the result
		if (isCelebrity) {
			System.out.println("The celebrity is: " + candidate);
		} else {
			System.out.println("There is no celebrity.");
		}
	}

	public static void main(String[] args) {
		celebrity_Graph obj = new celebrity_Graph();
		obj.createGraph(5);
		obj.printG();
		obj.findCelebrity();
	}
}
