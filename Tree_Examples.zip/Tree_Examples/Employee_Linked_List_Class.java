package Tree_Examples;

public class Employee_Linked_List_Class {
	private Employee head;

	public Employee_Linked_List_Class() {
		head = null;
	}

	public String addEmployee(int id, String name, double salary, String email) {
		if (findEmployee(id) != null) {
			return "Error: Employee ID already exists.";
		}

		Employee newEmployee = new Employee(id, name, salary, email);
		if (head == null) {
			head = newEmployee;
		} else {
			Employee current = head;
			while (current.next != null) {
				current = current.next;
			}
			current.next = newEmployee;
		}
		return "Employee registered successfully!";
	}

	public Employee findEmployee(int id) {
		Employee current = head;
		while (current != null) {
			if (current.id == id) {
				return current;
			}
			current = current.next;
		}
		return null;
	}

	public String displayEmployees() {

		if (head == null)
			return "No employees found.";

		String result = "";
		for (Employee current = head; current != null; current = current.next) {
			result += String.format("ID: %d, Name: %s, Salary: %.2f, Email: %s%n", current.id, current.name,
					current.salary, current.email);
		}
		return result;

	}
}
