package Tree_Examples;

	public class Tree_Class {
		private Node root;

		void create_Tree() {
			root = null;
		}

		void insert(Node n) {
			root = insertRecursive(root, n);
		}

		private Node insertRecursive(Node r, Node n) {
			if (r == null) {
				System.out.println(n.data + " inserted");
				return n; // New node becomes the root or a child
			}
			if (n.data < r.data) {
				r.left = insertRecursive(r.left, n); // Insert into left subtree
			} else {
				r.right = insertRecursive(r.right, n); // Insert into right subtree
			}
			return r; // Return unchanged node pointer
		}

		void inorder(Node r) {
			if (r != null) { // LPR
				inorder(r.left); // L
				System.out.print(r.data + ", "); // P
				inorder(r.right); // R
			}
		}

		void preorder(Node r) {
			if (r != null) { // PLR
				System.out.print(r.data + ", "); // P
				preorder(r.left); // L
				preorder(r.right); // R
			}
		}

		void postorder(Node r) {
			if (r != null) { // LRP
				postorder(r.left); // L
				postorder(r.right); // R
				System.out.print(r.data + ", "); // P
			}
		}

		boolean search(int key) {
			Node r = root;
			while (r != null) {
				if (key == r.data) {
					return true;
				} else if (key < r.data) {
					r = r.left;
				} else {
					r = r.right;
				}
			}
			return false;
		}

		int depth(Node r) {
			if (r == null) {
				return 0;
			} else {
				int left = depth(r.left);
				int right = depth(r.right);
				return Math.max(left, right) + 1;}
			}
		
		Node get_root() {
			return root;
		}

		public static void main(String[] args) {
			Tree_Class obj = new Tree_Class();
			obj.create_Tree();
			obj.insert(new Node(10));
			obj.insert(new Node(30));
			obj.insert(new Node(20));
			obj.insert(new Node(5));
			obj.insert(new Node(15));

			System.out.println("Tree has:");
			System.out.println("Preorder: ");
			obj.preorder(obj.root);
			System.out.println("\nInorder: ");
			obj.inorder(obj.root);
			System.out.println("\nPostorder: ");
			obj.postorder(obj.root);

			System.out.println("\nSearching for 20: " + obj.search(20));
			System.out.println("Depth of tree: " + obj.depth(obj.root));
		}

		
	}


