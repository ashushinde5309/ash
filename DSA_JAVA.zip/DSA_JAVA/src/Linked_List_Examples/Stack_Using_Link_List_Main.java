package Linked_List_Examples;

import java.util.Scanner;

import Stack_Examples.Stack_Class;

public class Stack_Using_Link_List_Main {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Stack_Using_LinkList obj = new Stack_Using_LinkList();
		obj.create_stack();
		int ch;
		do {
			System.out.println("Stack Menu");
			System.out.println(".....................");
			System.out.println("1.Push");
			System.out.println("2.pop");
			System.out.println("3.peek");
			System.out.println("4.Print all elements");
			System.out.println("0.Exit");
			System.out.println(".....................");
			System.out.println("Choice: ");
			ch = sc.nextInt();
			switch (ch) {
			case 1:
			
				System.out.println("Enter a number:");
				int e = sc.nextInt();
				obj.push(e);
				break;
			case 2:
				obj.pop();
				break;
			case 3:
				obj.peek();
				break;
			case 4:
				System.out.println("Elements in stack are\n");
				obj.print_stack();
				break;
			case 0:
				System.out.println("Thanks for using code , coded by amartechnavigator");
				break;
			default:
				System.out.println("Wrong option selsected:");
				break;
			}
		}while(ch!=0);
	
	}

}
