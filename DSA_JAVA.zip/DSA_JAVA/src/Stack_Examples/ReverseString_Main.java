
package Stack_Examples;

import java.util.Scanner;

public class ReverseString_Main {

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		Reverse_String_UsingStack obj = new Reverse_String_UsingStack();
		String word=sc.next();//read word from user 
		obj.create_Stack(word.length());
		for(int i=0;i<word.length();i++)//character by charater copy element to stack till all characters are over 
		{
			obj.push(word.charAt(i));
		}
		String r_word = "";
		while(obj.is_empty()!=true)//pop and copy each poped element to reverse string till stack over 
		{
			r_word=r_word+obj.pop();
		}

		System.out.println("Reverse is:"+r_word);//print reverse string }
		}
	}


