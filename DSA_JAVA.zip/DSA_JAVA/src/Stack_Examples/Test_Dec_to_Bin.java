package Stack_Examples;

import java.util.Scanner;

public class Test_Dec_to_Bin {
	static boolean check_wellness(String word)
	{
		Reverse_String_UsingStack obj=new Reverse_String_UsingStack();
		obj.create_Stack(word.length());
        for(int index=0;index<word.length();index++)
        {
            if(word.charAt(index)=='{')
                obj.push('{');
            else if (word.charAt(index)=='}')
            {
                if(obj.is_empty()!=true)
                {
                    char g=obj.pop();
                }
                else
                    return false;
            }
        }
        return obj.is_empty();
	}

	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter Data= ");
		String word=sc.next();
		System.out.println(word+" is balanced:"+check_wellness(word));

	}

	
}
