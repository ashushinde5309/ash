package Stack_Examples;

public class Circular_Queue {
	private int Q[];
	private int MaxSize;
	private int front;
	private int rear;
	private int count;

	public void create_Queue(int size) {
	MaxSize = size;//init MaxSize 
	front = 0;
	count=0;
	rear=-1;
	Q= new int[size];//create queue 
	}

	void Enqueue(int e) {
	rear=(rear+1)%MaxSize;
	Q[rear]=e;
	count++;
	System.out.println("Element " + e + " Inserted in Queue");
	}

	boolean is_Full() 
	{
	if (count == MaxSize) 
	{
	return true;
	}
	else
	{
	return false;
	}
	}

	int Dequeue() {
	int temp = Q[front];
	front=(front+1)%MaxSize;
	count--;
	return (temp);
	}

	boolean is_Empty() {
	if (count==0)
	return true;
	else
	return false;
	}

	void print_Queue()
	{//lifo print System.out.println("Queue has");
	int i,c;
	i=front;
	c=0;
	while(c<count)
	{
		System.out.println(Q[i]);
		i=(i+1)%MaxSize;
		c++;
	}
	}

	
}

