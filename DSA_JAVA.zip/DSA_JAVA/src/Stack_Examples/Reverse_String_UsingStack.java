
package Stack_Examples;

public class Reverse_String_UsingStack {
	private char stack[];
	private int MaxSize;
	private int tos;

	public void create_Stack(int size) {
		tos = -1;
		stack = new char[size];
		MaxSize = size;

	}

	void push(char e) {
		tos++;
		stack[tos] = e;
		System.out.println("Element " + e + " pushed");
	}

	boolean is_full() {
		if (tos == MaxSize - 1) {
			return true;

		} else {
			return false;
		}

	}

	char pop() {
		int temp = stack[tos];
		tos--;
		return (char)temp;

	}

	boolean is_empty() {
		if (tos == -1) {
			return true;

		} else {
			return false;
		}

	}

	int peek() {
		return stack[tos];
	}

	void print_Stack() {// lifo print System.out.println("Stack has");
		for (int i = tos; i >= 0; i--) {
			System.out.println(stack[i]);
		}

	}


}
