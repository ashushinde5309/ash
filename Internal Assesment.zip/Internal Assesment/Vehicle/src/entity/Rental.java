package entity;

public class Rental extends Vehicle
{
	String rentalId;
	String rentalDuration;
	
	public Rental(String vehicleId, String type, String rentalId, String rentalDuration) {
		super(vehicleId, type);
		this.rentalId = rentalId;
		this.rentalDuration = rentalDuration;
	}

	public String getRentalId() {
		return rentalId;
	}

	public void setRentalId(String rentalId) {
		this.rentalId = rentalId;
	}

	public String getRentalDuration() {
		return rentalDuration;
	}

	public void setRentalDuration(String rentalDuration) {
		this.rentalDuration = rentalDuration;
	}

	@Override
	public String toString() {
		return "Rental [rentalId=" + rentalId + ", rentalDuration=" + rentalDuration + ", vehicleId=" + vehicleId
				+ ", type=" + type + ", isAvailable=" + isAvailable + "]";
	}
	
	
	
}
