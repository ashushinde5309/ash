package entity;
import entity.Customer;
import entity.Rental;
import entity.Vehicle;
import java.util.ArrayList;

public class Transaction {
	ArrayList<Transaction> transaction;
	
	
	public Transaction(ArrayList<Transaction> transaction) {
		super();
		this.transaction = new ArrayList<Transaction>();
	}


	public void recordrentaltransaction()
	{
		
		for(Transaction transaction: transaction)
		{
			System.out.println("[ "+);
		}
			
	}
}
