package entity;

public class Vehicle 
{
    String vehicleId;
	String type;
	boolean isAvailable;
	public Vehicle(String vehicleId, String type) {
		
		this.vehicleId = vehicleId;
		this.type = type;
		this.isAvailable = true;
	}
	public String getVehicleId() {
		return vehicleId;
	}
	public void setVehicleId(String vehicleId) {
		this.vehicleId = vehicleId;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public boolean isAvailable() {
		return isAvailable;
	}
	public void setAvailable(boolean isAvailable) {
		this.isAvailable = isAvailable;
	}
	public void displayVehicleDetails()
	{
		System.out.println("Vehicle [vehicleId=" + vehicleId + ", type=" + type + ", isAvailable=" + isAvailable + "]");
	}
	

	
	
	
	
}
