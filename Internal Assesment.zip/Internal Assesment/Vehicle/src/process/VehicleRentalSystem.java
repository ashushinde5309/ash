package process;
import entity.Vehicle;
import entity.Customer;
import entity.Rental;
import java.io.*;
import java.util.ArrayList;
public class VehicleRentalSystem {
	
	private ArrayList<Vehicle> vehicleList = new ArrayList<>();
	private ArrayList<Customer> customerList = new ArrayList<>();
	private ArrayList<Rental> rentalList = new ArrayList<>();
	public void addVehicle(Vehicle vehicle) {
		vehicleList.add(vehicle);
		System.out.println("Vehicle added successfully.");
	}
	public void addCustomer(Customer customer) {
		customerList.add(customer);
		System.out.println("Customer added successfully.");
	}
	public void addRentalDetails(Rental rental) {
		rentalList.add(rental);
		System.out.println("Rental Details added successfully.");
	}

	public void listAvailableVehicles() {
		boolean hasAvailable = false;
		for (Vehicle vehicle : vehicleList) {
			if (!vehicle.isAvailable()) {
				System.out.println(vehicle);
				hasAvailable = true;
			}
		}
		if (!hasAvailable) {
			System.out.println("No available vehicles.");
		}
	}

	public void rentVehicle(String vehicleId) {
		for (Vehicle vehicle : vehicleList) {
			if (vehicle.getVehicleId() == vehicleId) {
				if (!vehicle.isAvailable()) {
					vehicle.setAvailable(true);
					System.out.println("Vehicle rented successfully.");
				} else {
					System.out.println("Vehicle is already rented.");
				}
				return;
			}
		}
		System.out.println("Vehicle not found.");
	}

	public void returnVehicle(String vehicleId) {
		for (Vehicle vehicle : vehicleList) {
			if (vehicle.getVehicleId()==vehicleId) {
				if (vehicle.isAvailable()) {
					vehicle.setAvailable(false);;
					System.out.println("Vehicle returned successfully.");
				} else {
					System.out.println("Vehicle is not currently rented.");
				}
				return;
			}
		}
		System.out.println("Vehicle not found.");
	}

}
