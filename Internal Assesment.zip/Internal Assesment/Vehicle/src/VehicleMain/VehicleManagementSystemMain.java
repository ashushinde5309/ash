package VehicleMain;
import java.util.*;

import entity.Customer;
import entity.Rental;
import entity.Vehicle;
import process.VehicleRentalSystem;
public class VehicleManagementSystemMain 
{

	public static void main(String[] args)
	{
		Scanner sc = new Scanner(System.in);
		VehicleRentalSystem vehicleRentalSystem= new VehicleRentalSystem();

		while (true) {
			System.out.println("\n.......Vehicle Rental System.............");
			System.out.println("1. Add Vehicle");
			System.out.println("2. Add Customer");
			System.out.println("3. List Available Vehicles");
			System.out.println("4. Rent Vehicle");
			System.out.println("5. Return Vehicle");
			System.out.println("6. Exit");
			System.out.print("Enter your choice: ");
			int choice = sc.nextInt();

			switch (choice) {
			case 1:
				String vehicleid;
				String type;
				try {
				System.out.println("Enter Vehicle ID: ");
				vehicleid = sc.nextLine();
				System.out.println("Enter Vehicle type: ");
				type = sc.nextLine();
				Vehicle vehicle=new Vehicle(vehicleid, type);
				vehicleRentalSystem.addVehicle(vehicle);;
				}
				catch(Exception e)
				{
					System.out.println("Please Enter valid Details ");
				}
			
				break;
			case 2:
				String customerid;
				String name;
				try {
				System.out.println("Enter Customer ID: ");
				customerid = sc.nextLine();
				System.out.println("Enter Customer name: ");
				name = sc.nextLine();
				Customer customer=new Customer(customerid, name);
				vehicleRentalSystem.addCustomer(customer);
				}
				catch(Exception e) {
					System.out.println("Please Enter valid Details ");
				}
				
				break;
				
			case 3:
				vehicleRentalSystem.listAvailableVehicles();
				break;

			case 4:
				System.out.println("Enter Vehicle ID to rent: ");
				vehicleid = sc.nextLine();
				System.out.println("Enter Vehicle type: ");
				type = sc.nextLine();
				System.out.println("Enter rental ID : ");
				String rentalId = sc.nextLine();
				System.out.println("Enter rental Duration : ");
				String rentalDuration = sc.nextLine();
				vehicleRentalSystem.addRentalDetails(new Rental(vehicleid, type, rentalId, rentalDuration));
				
				break;

			case 5:
				System.out.println("Enter Vehicle ID to return: ");
				vehicleid = sc.nextLine();
				System.out.println("Enter Vehicle type: ");
				type = sc.nextLine();
				System.out.println("Enter rental ID : ");
				rentalId = sc.nextLine();
				System.out.println("Enter rental Duration : ");
				rentalDuration = sc.nextLine();
				vehicleRentalSystem.addRentalDetails(new Rental(vehicleid, type, rentalId, rentalDuration));
				break;

			case 6:
				System.out.println("...........Thank You For using Vehicle Rental System...........");
				sc.close();
				return;

			default:
				System.out.println("Invalid choice, please try again.");
			}
		}
	}

}
